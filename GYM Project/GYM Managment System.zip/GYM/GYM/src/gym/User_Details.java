/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gym;

import com.data.connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.joda.time.DateTime;
import org.joda.time.Days;
import java.util.ArrayList; 
import java.util.LinkedHashSet;
/**
 *
 * Name: marwan moataz
 * ID: 19107708
 */
public class User_Details {
    
    String id =""
            ,name =""
            ,pass=""
            ,address=""
            ,pn=""
            ,sex=""
            ,age=""
            ,status=""
            ,banned=""
            ,rdate=""
            ,expired=""
            ,memb_type=""
            ,enddate="";
           String old_name="";
           int  ni_pub = 0;
           int flag = 0;
           
           Object data[]=new Object[]{""};
ArrayList<String> listWithoutDuplicates ;

         Connection con =connection.connect();
    PreparedStatement ps =null;
    ResultSet rs=null;
                String get_user_db = "SELECT * FROM `users` WHERE id = ";

   
    public User_Details(String id){
                try {
                    this.id = id;
                    ps = con.prepareStatement(get_user_db+id);
                    rs = ps.executeQuery();
                } catch (SQLException ex) {
                    Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                }  
    }
    

    public void UpdateInfo(String id, String name, String pass,String address,String pn ,String sex,String age){

                try {
                    
                    String updated = "UPDATE users SET name = ? , password = ? , address = ?, pn = ? , sex = ? , age = ? WHERE id = "+id;
                    this.old_name = get_name();
                    this.name = name;
         this.pass = pass;
         this.address=address;
         this.pn=pn;
        this.sex=sex;    
        this.age=age;
                  if(!check_userExsist(name)){
                      ps = con.prepareStatement(updated);
                    ps.setString(1, name);
                    ps.setString(2 ,pass);
                    ps.setString(3, address);
                    ps.setString(4, pn);
                    ps.setString(5 ,sex);
                    ps.setString(6, age);
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Your Information Updated");
                    
                  }
                  else{
                      JOptionPane.showMessageDialog(null, "This UserName Is Exsist");
                  }
                        
                      
                    
    } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                        
                }
                
    
}
    String get_idByName(String name){
       try{
        String get_uname = "SELECT * FROM `users` WHERE name = '"+name+"'";
            ps = con.prepareStatement(get_uname);
            rs= ps.executeQuery();
            String user_id = rs.getString("id");
            return user_id;
       }catch(SQLException ex) {
}
       return "";
    }

    boolean check_userExsist(String user){
                    boolean result = true;

        try {
            
         String get_uname = "SELECT * FROM `users` WHERE name = '"+user+"'";
            ps = con.prepareStatement(get_uname);
            rs= ps.executeQuery();
if(rs.getString("name").equals(this.old_name)&&this.old_name.equals(user)){
    System.out.println("me");
    result = false;
}else if(rs.next()){
    System.out.println("exsitst");
    result = true;
    
}

        } catch (SQLException ex) {
            System.out.println("not found put on me");
    result = false;
        }
        return result;
    }
    
    boolean check_userExsistForCoach(String user){
        boolean result = true;

        try {
            
         String get_uname = "SELECT * FROM `users` WHERE name = '"+user+"'";
            ps = con.prepareStatement(get_uname);
            rs= ps.executeQuery();
            if(rs.next()){
                result =true;
            }
            else
            {
                result = false;
            }
    }catch(Exception ex){
        
    }
        return result;
    }
    Object[] get_allNameForCoach(){
        ArrayList<String> namesx = new ArrayList<String>();
        try {
            String get_unames = "SELECT * FROM `users` WHERE c_id = '"+id+"'";
            ps = con.prepareStatement(get_unames);
            rs= ps.executeQuery();
            namesx.add("All Users");
            while(rs.next()){
                namesx.add(rs.getString("name"));
            }
            return namesx.toArray();
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return namesx.toArray();
    }
     Object[] get_allNameForAdmin(){
        ArrayList<String> namesx1 = new ArrayList<String>();
        try {
            String get_unames = "SELECT * FROM `users`";
            ps = con.prepareStatement(get_unames);
            rs= ps.executeQuery();
            while(rs.next()){
                namesx1.add(rs.getString("name"));
            }
            return namesx1.toArray();
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return namesx1.toArray();
    }
    
int get_rday(){

   SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
Date d1 = null;
    Date d2 = null;
    String srdate = String.valueOf(LocalDate.now());
    System.out.println(srdate);
    String enddate = this.enddate;
        try {
            d1 = format.parse(srdate);
        d2 = format.parse(enddate);
        DateTime dt1 = new DateTime(d1);
        DateTime dt2 = new DateTime(d2);
         return Days.daysBetween(dt1, dt2).getDays();
        

 } catch (ParseException ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
        }
return 0;
}
    public String get_id()
    {
        
        return id;
    }
    public String get_name()
    {
        
        try {
            
             String name = rs.getString("name");
             this.name=name;
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
            
          return name;   
    }
    public String get_pass()
    {
        try {
            String pass = rs.getString("password");
            this.pass=pass;
            
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return pass;
    }
    public String get_address()
    {
         try {
            String address = rs.getString("address");
            this.address=address;
            
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return address;
    }
    public String get_pn()
    {
        try {
            String pn = rs.getString("pn");
            this.pn=pn;
            
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return pn;
    }
    
    public String get_sex()
    {
         try {
            String sex = rs.getString("sex");
            this.sex=sex;
            
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sex;
    }
   
    public String get_age()
    {
         try {
            String age = rs.getString("age");
            this.age=age;
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return age;
    }
    public String get_status()
    {
        try {
            String status = rs.getString("status");
            this.status=status;
            
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return status;
    }
    public String get_banned()
    {
        try {
            String banned = rs.getString("banned");
            this.banned=banned;
            
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return banned;
    }
    public String get_rdate()
    {
        try {
            String rdate = rs.getString("rdate");
            this.rdate=rdate;
            
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rdate;
    }
     public String get_enddate()
    {
        try {
            String enddate = rs.getString("enddate");
            this.enddate=enddate;
            
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return enddate;
    }
    public String get_expired()
    {
        
        return expired;
    }
    public String get_memb_type()
    {
        try {
            String memb_type = rs.getString("memb_type");
            this.memb_type=memb_type;
            if(memb_type.equals("0")){
                this.memb_type = "1MONTH";
            }
            else if(memb_type.equals("1")){
                this.memb_type = "6MONTHS";
            }
            else if(memb_type.equals("2")){
                this.memb_type = "1Year";
            }
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
        return memb_type;
    }
    
   public String get_notification(String m_id){
           String get_notif = "SELECT * FROM `notification` WHERE m_id = ";
            String senter_name = "";
                    String msg = "";
                    String time =   "";
                    String msg_1="";
                   int i=-1;
           try {
                    ps = con.prepareStatement(get_notif+m_id);
                    rs = ps.executeQuery();
                                        while(rs.next()){
                     senter_name = rs.getString("senter_name");
                     msg = rs.getString("msg");
time = rs.getString("time");
                    msg_1 += "Sent From:"+senter_name+"\nMsg:\n"+msg+"\nTime:"+time+"\n__________________________\n";
                    }
                    
                }catch(Exception ex){
                                Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                }
       return msg_1;
   }
   int get_notification_count(){
         try {
          String get_schedule = "SELECT * FROM `notification` WHERE senter_name = '"+name+"';";
        
                    ps = con.prepareStatement(get_schedule);
                    rs = ps.executeQuery();
        while(rs.next()){
            ni_pub++;
        }
             System.out.println(ni_pub);
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
   return ni_pub;
    }
   
    Object[] get_notification_ById(){
   try{
        ArrayList<String> m_names = new ArrayList<String>();
       String table_id="";
       String senter_name="";
       String m_id="";
        String m_name="";
       String msg="";
       String time = "";
          if (flag==0){
       
         String get_schedule = "SELECT * FROM `notification` WHERE c_id = '"+id+"'";
        
      ps = con.prepareStatement(get_schedule);
                    rs = ps.executeQuery();
          flag=1;}
          rs.next();
          table_id = rs.getString("id");
        senter_name= rs.getString("senter_name");
        m_id = rs.getString("m_id");
        m_name = rs.getString("m_name");
        m_names.add(rs.getString("m_name"));
        msg = rs.getString("msg");
        time = rs.getString("time");
               LinkedHashSet<String> hashSet = new LinkedHashSet<>(m_names);
            listWithoutDuplicates   = new ArrayList<>(hashSet);
data = new Object[] {table_id,senter_name,m_id,m_name,msg,time};
                       return data;

      }catch(Exception e){
              Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, e);

      }
       return null;
    }
    void update_Notification(String id,String m_name,String m_id,String msg){
        try {
            String updated = "UPDATE notification SET m_name = ? , m_id = ? , msg = ? WHERE id = "+id;
             ps = con.prepareStatement(updated);
            ps.setString(1, m_name);
            ps.setString(2, m_id);
            ps.setString(3, msg);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Your Information Updated");
        } catch (SQLException ex) {
            Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    void insert_Notification(String senter_name,String m_name,String c_id,String m_id,String msg,String time){
         String insert_newNotification = "INSERT INTO notification (senter_name, m_name, c_id, m_id, msg, time) VALUES('"+senter_name+"','"+m_name+"','"+c_id+"','"+m_id+"','"+msg+"','"+time+"');";
          try {
                      PreparedStatement stmt = con.prepareStatement(insert_newNotification);
stmt.executeUpdate();
    JOptionPane.showMessageDialog(null, "Notification Sent.");
      } catch (SQLException ex) {
                   JOptionPane.showMessageDialog(null, "Error In add Notification");
                    Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    
   void conclose(){
       try{
       con.close();
       }
       catch(Exception x){
           
       }
   }
   
 

//coded with ❤ by marwaneldesouki
}
