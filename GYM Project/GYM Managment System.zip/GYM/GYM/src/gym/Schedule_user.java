/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gym;

import com.data.connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * Name: marwan moataz
 * ID: 19107708
 */
public class Schedule_user  {
String id ="";
String  cname="";
String cid="";
String  Type_ex="";
String  Day="";
String  Month="";
String  Time="";
String m_name="";
String sch_id="";
    int i_pub=0;
    int flag=0;
       Object data[]=new Object[]{""};



      Connection con = connection.connect();;
    PreparedStatement ps =null;
    ResultSet rs=null;
    public Schedule_user(String id){
       this.id = id;
      String get_schedule = "SELECT * FROM `schedule` WHERE m_id = ";
         try {
                    ps = con.prepareStatement(get_schedule+id);
                    rs = ps.executeQuery();
               } catch (SQLException ex) {
                   
                    Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                }
         
    }
    public String get_cname()
         {
    try {
        this.cname=rs.getString("c_name");
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
             return cname;
         }
     public String get_cid()
         {
    try {
        this.cid=rs.getString("c_id");
       
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
    return cid;
         }
 
   Object[] get_sch_data(){
      try{
          rs.next();
            Type_ex = rs.getString("Type_ex");
            Day = rs.getString("day");
            Month = rs.getString("month");
            Time = rs.getString("time");
data = new Object[] {Type_ex,Day,Month,Time};
                       return data;

      }catch(Exception e){
      
      }
       return null;
   }
    int get_schedule_count(){
        try {
        while(rs.next()){
            i_pub++;
        }
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
   return i_pub;
    }
    public String get_cpn(){
        String CPN ="";
      
            String gcid = get_cid();
       
        User_Details coach = new User_Details(gcid);
      CPN = coach.get_pn();
    
   
      
       return CPN;
       
    }
    int get_Allschedule_count(){
         try {
              String get_schedule = "SELECT * FROM `schedule` WHERE c_id = ";
                    ps = con.prepareStatement(get_schedule+id);
                    rs = ps.executeQuery();
        while(rs.next()){
            i_pub++;
        }
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
   return i_pub;
    }
    int get_schByName_count(String u_name){
         try {
              String get_schedule = "SELECT * FROM `schedule` WHERE c_id = "+id+" and m_name = '"+u_name+"'";
                    ps = con.prepareStatement(get_schedule);
                    rs = ps.executeQuery();
        while(rs.next()){
            i_pub++;
        }
             System.out.println(i_pub);
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
   return i_pub;
    }
    int get_sch_today_count(){
         try {
              Date d=new Date();
        Date m=new Date();
        String get_schedule="";
        if(String.valueOf(d.getDate()).length()<2){
          get_schedule = "SELECT * FROM `schedule` WHERE c_id = '"+id+"' and day = '0"+d.getDate()+"' and month = '0"+(m.getMonth()+1)+"'";
        }
        else{
          get_schedule = "SELECT * FROM `schedule` WHERE c_id = '"+id+"' and day = '"+d.getDate()+"' and month = '"+(m.getMonth()+1)+"'";
        }
                    ps = con.prepareStatement(get_schedule);
                    rs = ps.executeQuery();
        while(rs.next()){
            i_pub++;
        }
             System.out.println(i_pub);
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
   return i_pub;
    }
    
    Object[] get_Allsch_data(){
      try{
          if (flag==0){
           String get_schedule = "SELECT * FROM `schedule` WHERE c_id = ";
                    ps = con.prepareStatement(get_schedule+id);
                    rs = ps.executeQuery();
          flag=1;}
          rs.next();
          sch_id = rs.getString("id");
          m_name= rs.getString("m_name");
            Type_ex = rs.getString("Type_ex");
            Day = rs.getString("day");
            Month = rs.getString("month");
            Time = rs.getString("time");
data = new Object[] {sch_id,m_name,Type_ex,Day,Month,Time};
                       return data;

      }catch(Exception e){
      
      }
       return null;
   }
    Object[] get_schByName_data(String u_name){
      try{
          if (flag==0){
           String get_schedule = "SELECT * FROM `schedule` WHERE c_id = "+id+" and m_name = '"+u_name+"'";
                    ps = con.prepareStatement(get_schedule);
                    rs = ps.executeQuery();
          flag=1;}
          rs.next();
          sch_id = rs.getString("id");
          m_name= rs.getString("m_name");
            Type_ex = rs.getString("Type_ex");
            Day = rs.getString("day");
            Month = rs.getString("month");
            Time = rs.getString("time");
data = new Object[] {sch_id,m_name,Type_ex,Day,Month,Time};
                       return data;

      }catch(Exception e){
      
      }
       return null;
   }
    
  Object[] get_sch_today(){
   try{
          if (flag==0){
        Date d=new Date();
        Date m=new Date();
                String get_schedule="";
        if(String.valueOf(d.getDate()).length()<2){
          get_schedule = "SELECT * FROM `schedule` WHERE c_id = '"+id+"' and day = '0"+d.getDate()+"' and month = '0"+(m.getMonth()+1)+"'";
        }
        else{
          get_schedule = "SELECT * FROM `schedule` WHERE c_id = '"+id+"' and day = '"+d.getDate()+"' and month = '"+(m.getMonth()+1)+"'";
        }
      ps = con.prepareStatement(get_schedule);
                    rs = ps.executeQuery();
          flag=1;}
          rs.next();
          sch_id = rs.getString("id");
          m_name= rs.getString("m_name");
            Type_ex = rs.getString("Type_ex");
            Day = rs.getString("day");
            Month = rs.getString("month");
            Time = rs.getString("time");
data = new Object[] {sch_id,m_name,Type_ex,Day,Month,Time};
                       return data;

      }catch(Exception e){
      
      }
       return null;
    }
  void set_new_sch(String cname,String m_id,String mname,String Type_ex,String day,String month,String time ){
       String insert_newUser = "INSERT INTO schedule (c_id, c_name, m_id, m_name, Type_ex, day, month, time) VALUES('"+id+"','"+cname+"','"+m_id+"','"+mname+"','"+Type_ex+"','"+day+"','"+month+"','"+time+"');";
          try {
                      PreparedStatement stmt = con.prepareStatement(insert_newUser);
stmt.executeUpdate();
    JOptionPane.showMessageDialog(null, "New schedule added");

               } catch (SQLException ex) {
                   JOptionPane.showMessageDialog(null, "This UserName Is Exsist");
                    Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                }
  }
        void update_sch_data_byID(String id,String m_id,String user,String Type_ex,String day,String month,String time){
    try {
        String updated = "UPDATE schedule SET m_id = ? , m_name = ? , Type_ex = ? , day = ?, month = ? , time = ? WHERE id = "+id;
        
        ps = con.prepareStatement(updated);
        ps.setString(1, m_id);
        ps.setString(2, user);
        ps.setString(3 ,Type_ex);
        ps.setString(4, day);
        ps.setString(5, month);
        ps.setString(6 ,time);
        ps.executeUpdate();
        JOptionPane.showMessageDialog(null, "Your Information Updated");
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
        }
        void delete_sch_selected(String id){
    try {
        String updated = "DELETE FROM schedule WHERE id = "+id;
        ps = con.prepareStatement(updated);
        ps.execute();
        JOptionPane.showMessageDialog(null, "Your Selected Row Deleted");
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }


        }
        
        
   void conclose(){
       try{
       con.close();
       }
       catch(Exception x){
           
       }
   }
//coded with ❤ by marwaneldesouki
}
