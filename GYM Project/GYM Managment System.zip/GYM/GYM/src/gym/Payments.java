/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gym;

import com.data.connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.util.UUID;
/**
 *
 * Name: marwan moataz
 * ID: 19107708
 */
public class Payments {
String mid="";
String price="";
String status="";
String cardNum = "";
String TransactionID="";
String TypeMmeberShip="";
Connection con = connection.connect();;
    PreparedStatement ps =null;
    ResultSet rs=null;
    Payments(String id){
        this.mid=id;
         String get_payments = "SELECT * FROM payments WHERE m_id = "+mid+" ORDER BY id DESC ";
         try {
                    ps = con.prepareStatement(get_payments);
                    rs = ps.executeQuery();
               } catch (SQLException ex) {
                   
                    Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    String get_transactionid(){
         try {
        this.TransactionID=rs.getString("TransactionId");
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
             return TransactionID;
        
    }
     String get_TypeMemberShip(){
         try {
        this.TypeMmeberShip=rs.getString("type_membership");
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
             return TypeMmeberShip;
        
    }
     String get_price(){
         try {
        this.price=rs.getString("price");
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
             return price;
        
    }
      String get_status(){
         try {
        this.status=rs.getString("status");
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
             return status;
        
    }
       String get_cardNum(){
         try {
        this.cardNum=rs.getString("cardNum");
    } catch (SQLException ex) {
        Logger.getLogger(Schedule_user.class.getName()).log(Level.SEVERE, null, ex);
    }
             return cardNum;
        
    }
       void set_status(String transid){
    try {
        ps = con.prepareStatement("UPDATE payments SET status = 'completed' WHERE TransactionId = '"+transid+"'");
        ps.executeUpdate();
    } catch (SQLException ex) {
        Logger.getLogger(Payments.class.getName()).log(Level.SEVERE, null, ex);
    }
       }
       
  
         String TransActionidGen() {
 Random rnd = new Random();
    int number = rnd.nextInt(999999);

    // this will convert any number sequence into 6 character.
return String.format("%06d", number);
}
       void set_newPayment(String cid,String price,String Memtybe)
       {
            String insert_newUser = "INSERT INTO payments (m_id, c_id, price, status, TransactionId, Type_membership) VALUES('"+mid+"','"+cid+"','"+price+"','pending','"+TransActionidGen()+mid+"','"+Memtybe+"');";
          try {
                      PreparedStatement stmt = con.prepareStatement(insert_newUser);
stmt.executeUpdate();
    JOptionPane.showMessageDialog(null, "New Payment Made");

               } catch (SQLException ex) {
                   JOptionPane.showMessageDialog(null, "This UserName Is Exsist");
                    Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                }
       }
       void conclose(){
       try{
       con.close();
       }
       catch(Exception x){
           
       }
   }
//coded with ❤ by marwaneldesouki
}
