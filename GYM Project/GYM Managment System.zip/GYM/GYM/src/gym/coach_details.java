/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gym;

import com.data.connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.joda.time.DateTime;
import org.joda.time.Days;

/**
 *
 * Name: marwan moataz
 * ID: 19107708
 */
public class coach_details {
 Connection con = connection.connect();;
    PreparedStatement ps =null;
    ResultSet rs=null;
    
    String id ="";
    int totalusers=0;
    int totalPayment=0;
                int totalExpiredMembers=0;

     
                            
    
    coach_details(String id){
        this.id = id;
    }
    
    int get_Totalpayments(){
        String get_totalpayments = "SELECT * FROM `payments` WHERE c_id = "+id;
         try {
                    ps = con.prepareStatement(get_totalpayments);
                    rs = ps.executeQuery();
                    while(rs.next()){
                        totalPayment++;
                    }
               } catch (SQLException ex) {
                   
                    Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                }
        return totalPayment;
    }
    int get_Totalusers(){
        String get_totalusers = "SELECT * FROM `users` WHERE c_id = '"+id+"'";
         try {
                    ps = con.prepareStatement(get_totalusers);
                    rs = ps.executeQuery();
                    while(rs.next()){
                        totalusers++;
                    }
               } catch (SQLException ex) {
                   
                    Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                }
        return totalusers;
    }
    int get_TotalExpiredMembers(){
        String get_totalExpiredMembers = "SELECT * FROM `users` WHERE c_id = '"+id+"' and expired = 1";
        totalExpiredMembers = 0; 
        try {
                    ps = con.prepareStatement(get_totalExpiredMembers);
                    rs = ps.executeQuery();
                    while(rs.next()){
                        totalExpiredMembers++;
                    }
               } catch (SQLException ex) {
                   
                    Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                }
        return totalExpiredMembers;
    }
    String get_regday(){

   SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
Date d1 = null;
    String srdate = String.valueOf(LocalDate.now());
       return srdate;
}
    String get_endDay(String memType){
                LocalDate date = LocalDate.now() ;
                String srdate="";
        if(memType.equals("0")){
            //month-30days
                     srdate = String.valueOf(date.plusDays(30));

        }else if(memType.equals("1")){
            //6months
         srdate = String.valueOf(date.plusMonths(6));
        }else if(memType.equals("2")){
            //1year
         srdate = String.valueOf(date.plusYears(1));
        }
        return srdate;
    }
    void add_newUser(String name,String pw , String address , String pn,String usersex, String age,String memType,String coach_id){
         String insert_newUser = "INSERT INTO users (name, password, address, pn, sex, age, status, banned, rdate, enddate, expired, memb_type, c_id) VALUES('"+name+"','"+pw+"','"+address+"','"+pn+"','"+usersex+"','"+age+"','2','0','"+get_regday()+"','"+get_endDay(memType)+"','0','"+memType+"','"+id+"');";
          try {
                      PreparedStatement stmt = con.prepareStatement(insert_newUser);
stmt.executeUpdate();
    JOptionPane.showMessageDialog(null, "New User Added");

               } catch (SQLException ex) {
                   JOptionPane.showMessageDialog(null, "This UserName Is Exsist");
                    Logger.getLogger(User_Details.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    void ban_User(String name,String ban){
     try {
         String updated = "UPDATE users SET banned = ? WHERE id = "+id;
         ps = con.prepareStatement(updated);
         if(ban.equals("0")){
         ps.setString(1, ban);
          ps.executeUpdate();
    JOptionPane.showMessageDialog(null, "UnBaned User Done");
         }
         else{
             ps.setString(1, ban);
             ps.executeUpdate();
    JOptionPane.showMessageDialog(null, "Banned User Done");
         }
        
     } catch (SQLException ex) {
         Logger.getLogger(coach_details.class.getName()).log(Level.SEVERE, null, ex);
     }
    }
     void conclose(){
       try{
       con.close();
       }
       catch(Exception x){
           
       }
   }
//coded with ❤ by marwaneldesouki
}
