
package com.data;
import java.sql.*;
import javax.swing.JOptionPane;
  
     
    public class connection {
     
    public static Connection connect() {
     
    try {
    Class.forName("org.sqlite.JDBC");
     
    Connection con = DriverManager.getConnection("jdbc:sqlite:G:\\gam3a\\OOP\\GYM\\GYM\\src\\gym\\gym.db");
    return con;
     
    } catch (Exception e) {
    JOptionPane.showMessageDialog(null, "cant connect to database");
    }
    return null;
    }
     
    public static void main(String[] args) {
    connection.connect();
     
    }
     
    }
